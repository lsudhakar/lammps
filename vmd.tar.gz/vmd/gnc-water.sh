vmd -dispdev text -e gnc.tcl
vmd -dispdev text -e gnc-water.tcl
exit
