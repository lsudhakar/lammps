rm -f *pdb
rm -f *psf
rm -f *log
rm -f *lmpsys
