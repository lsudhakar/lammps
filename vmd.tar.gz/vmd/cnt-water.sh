vmd -dispdev text -e cnt.tcl
vmd -dispdev text -e center.tcl
vmd -dispdev text -e cnt-water.tcl
vmd -dispdev text -e cut-water.tcl
exit
